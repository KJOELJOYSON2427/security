package com.sivalabs.messages;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessagesWebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessagesWebappApplication.class, args);
	}

}
